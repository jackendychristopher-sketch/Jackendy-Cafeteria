{
  "stock": {
    "pain": 12.0,
    "viande": 10.0,
    "fromage": 8.0,
    "cafe": 15.0,
    "lait": 10.0
  },
  "produits": {
    "P01": {
      "identifiant": "P01",
      "nom": "Burger Fromage",
      "prix": 350.0,
      "recette": {
        "pain": 1.0,
        "viande": 1.0,
        "fromage": 1.0
      }
    },
    "P02": {
      "identifiant": "P02",
      "nom": "Café au Lait",
      "prix": 150.0,
      "recette": {
        "cafe": 1.0,
        "lait": 1.0
      }
    }
  },
  "clients": {
    "E01": {
      "identifiant": "E01",
      "nom": "Nadège Pierre",
      "type_client": "etudiant",
      "remise": 0.15
    },
    "PER01": {
      "identifiant": "PER01",
      "nom": "Marc-Antoine Joseph",
      "type_client": "personnel",
      "remise": 0.10
    },
    "C01": {
      "identifiant": "C01",
      "nom": "Invité Campus",
      "type_client": "client",
      "remise": 0.0
    }
  },
  "commandes": {
    "CMD01": {
      "identifiant": "CMD01",
      "client_id": "E01",
      "articles": {
        "P01": 2
      },
      "statut": "en_preparation",
      "montant_final": 595.0
    }
  },
  "historique": [
    {
      "date": "2026-11-23 17:30:00",
      "action": "INITIALISATION",
      "details": "Jeu de données de démonstration chargé."
    }
  ]
}